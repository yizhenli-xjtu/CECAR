# -*- coding:utf-8 -*-
from dateutil.parser import parse
import pandas as pd
import os
import numpy as np
from scipy.optimize import leastsq
##查找目录下所有的trace文件
def findtxt(path, ret):
    #将文件夹中所有的文件取出来放到list集合中
    filelist = os.listdir(path)
    #循环集合
    for filename in filelist:
        de_path = os.path.join(path, filename)
        if os.path.isfile(de_path):
            if de_path.find('.csv')>=0:
                # if de_path.find(".xlsx")>=0 or de_path.find(".csv")>=0:
                ret.append(de_path)
        else:
            findtxt(de_path, ret)

#判断 是否存在某文件夹 如果并不存在新建文件夹
def mkdir(path):
    # 引入模块
    import os
    # 去除首位空格
    path = path.strip()
    # 去除尾部 \ 符号
    path = path.rstrip("\\")
    # 判断路径是否存在
    # 存在     True
    # 不存在   False
    isExists = os.path.exists(path)
    # 判断结果
    if not isExists:
        # 如果不存在则创建目录
        # 创建目录操作函数
        os.makedirs(path)
        print
        path + ' 创建成功'
        return True
    else:
        # 如果目录存在则不创建，并提示目录已存在
        print
        path + ' 目录已存在'
        return False

root = "D:\全场景运行建模\数据\第六次幂律验证局点数据\Alarm_0701-0916_2个月\Alarm"
ret = []
# 调用findtxt找到处理前文件夹下所有带trace的文件放到ret集合中
findtxt(root, ret)
print(len(ret))
print('---------------------------------')
contents = []
df_main = pd.DataFrame(columns=['告警ID','网元类型','发生时间(NT)'])
print(df_main)

# 循环所有带csv的文件，并按照行读取
for path in ret:
    # 读取文件
    print(path)

    df_main = pd.read_csv(path, encoding='utf-8')
    # 先转化成列表，再逐行读取
    '''list_df = df_csv.values.tolist()
    #print(list_df)
    for line in list_df:
        # strfirstline = line.strip('\n')
        # print(line)
        # print('---------------------------------')
        contents.append(line)
print(contents)'''
#将大列表转化为df
print(df_main)
list_wylx = df_main['NE Type'].unique()
list_gjid = df_main['Alarm ID'].unique()
print(list_wylx)
print(list_gjid)
#list_wylx = ["BTS3900 LTE","BTS3205E",'NodeB530',"OSS",'USU3910']
#list_gjid = [50,301,780,832,25888,25954,26121,26235,26270,26322,26529,26817,29201,29240,29245,29248]
for insid in list_wylx:
    #按告警id维度分析
    # df1 = df_main[df_main['告警ID']==insid].reset_index(drop=True)
    #按网元类型维度分析
    df1 = df_main[df_main['NE Type'] == insid].reset_index(drop=True)
    for wylxid in list_gjid:

        df11 = df1[df1['Alarm ID'] == wylxid].reset_index(drop=True)

        # print(df1)
        #只保留告警id与时
        df2 = df11[['Alarm ID','Occurred On (NT)']]
        print(df2)

        #按时间排序
        df3 = df2.sort_values(by="Occurred On (NT)",ascending=True)
        print(df3)
        #csv格式写入文件
        # df3.to_csv(r'C:\Users\Administrator\Desktop\29250.csv',index=False)

        #计算时间间隔
        # df = pd.read_csv(r"C:\Users\Administrator\Desktop\29250.csv")
        # print(df)
        list_df = df3["Occurred On (NT)"].values.tolist()
        # print(list_df)
        sjjg = []
        i = 0
        # print('++++++++++++++++')
        # print(len(list_df))
        # print('++++++++++++++++')
        for i in range(len(list_df)):

            if i == len(list_df)-1:
                break
            else:
                qianyishike = list_df[i]
                houyishike = list_df[i+1]
            # print('++++++++++++++++')
            # print(qianyishike)
            # print(houyishike)
            # print('++++++++++++++++')
                a = parse(qianyishike)
                b = parse(houyishike)
                e = (b-a).total_seconds()
                e = round(e/60)
                print(e)
                sjjg.append(e)
        data = pd.DataFrame(sjjg,columns=["sjc"])
        print(data)
        #orgin统计个数
        #遍历每行，加1
        list_tongji = []
        for index, row in data.iterrows():
            sjc = row['sjc']  #之前没有这一行时一直说sjc没有定义
            list_tongji.append([sjc, 1])
        #列表转df定义列名称
        df_tongji = pd.DataFrame(list_tongji,columns=['τ/分钟','M（τ）'])
        print(df_tongji)
        #空列表直接跳过开始下一次循环
        if len(df_tongji) == 0:
            continue
        #求和
        df_tongji_sum = df_tongji.groupby(['τ/分钟'], as_index=False)['M（τ）'].sum()
        print(df_tongji_sum)
        #保存
        mkdir(r"./输出/时间间隔统计/网元类型+ID/{}".format(insid))
        df_tongji_sum.to_csv(r"./输出/时间间隔统计/网元类型+ID/{}/{}.csv".format(insid,wylxid), index=False)

# 进行一个幂率的算
def Fun(p, x):  # 定义拟合函数形式
    c, a = p
    return c * np.power(x, -a)
    # return c * x * a

def error(p, x, y):  # 拟合残差
    return Fun(p, x) - y

def dange(filename):
    #    data = pd.read_csv(r'./21801.csv',encoding = 'gbk')
    data = pd.read_csv(filename)

    #切分路径，读取网元类型和告警ID
    ret_path = filename.split('\\')
    NE = ret_path[-2]
    id = ret_path[-1].split('.')[0]

    if data.index.size == 0:
        print('空文件夹，跳过')
        result.loc[result.index.size] = {'网元类型': NE, '告警ID': id, '告警数量': 0, '幂律指数': 0}
        return

    datax = []
    datay = []
    data_count = 0
    for j in range(0, data.index.size):
        #时间间隔整体加1，以便计算到时间间隔为0的那部分数据
        if (data['τ/分钟'][j] >= 0):
            datax.append(data['τ/分钟'][j]+1)
            datay.append(data['M（τ）'][j])
            data_count += data['M（τ）'][j]

    # 如果告警总量小于1000个，则不拟合
    # 之前拟合的时候，好像1000个以下的，都不行
    if data_count <= 10:
        print('告警总量小于1000，跳过')
        # 如果数据中只有大于拟合上限的时间间隔
        result.loc[result.index.size] = {'网元类型': NE, '告警ID': id, '告警数量': data_count, '幂律指数': 0, '最小时间间隔': datax[0]-1, '最大时间间隔':datax[-1]-1}
        return

    # y = Fun(p_value,x)+noise*2 # 加上噪声的序列

    p0 = [0.1, 0.1]  # 拟合的初始参数设置
    para = leastsq(error, p0, args=(np.array(datax), np.array(datay)))  # 进行拟合
    y_fitted = Fun(para[0], datax)  # 画出拟合后的曲线
    print(para[0])
    print(para[0].tolist()[1])

    result.loc[result.index.size] = {'网元类型': NE, '告警ID': id, '告警数量': data_count, '幂律指数': para[0].tolist()[1], '最小时间间隔': datax[0]-1, '最大时间间隔':datax[-1]-1}

    # plt.figure
    # plt.plot(datax, datay, 'r', label='Original curve')
    # plt.plot(datax, y_fitted, '-b', label='Fitted curve')
    # plt.legend()
    # plt.show()

def digui(dirname):

    dir_list = os.listdir(dirname)
    for cur_dir in dir_list:
        cur_dir = os.path.join(dirname, cur_dir)
        file_list = os.listdir(cur_dir)
        for file in file_list:
            file = os.path.join(cur_dir, file)
            print(file + ': ')
            dange(file)

result = pd.DataFrame(columns=['网元类型','告警ID','告警数量','幂律指数',"最小时间间隔","最大时间间隔"])
dirname = './输出/时间间隔统计/网元类型+ID'
digui(dirname)
print(result)
for index, row in result.iterrows():

    count = row['告警数量']
    print(index)
    print(count)
    if count <= 100:
        result = result.drop(index, axis=0)
print("\n\n\n","告警ID分布计算完成!")
result.to_csv(r'./输出/幂律分布计算结果.csv', index=False)