 # -*- coding:utf-8 -*-

import pandas as pd
import numpy as np
import random
from configparser import ConfigParser   # Python2中是from ConfigParser import ConfigParser

def rndm(min, max, g):
    # 按照幂律指数生成符合幂律分布的随机数
    # min <= x <= max
    # P(x)=const * x^-b = const * x^(g-1)
    # 分布为：g * x^(g-1) / (bg-ag)
    r = np.random.random()
    ag, bg = min**g, max**g
    return (ag + (bg - ag) * r) ** (1./g)

def time_to_str(time):
    # 将timedelta转化为字符串并只保留时间
    string = str(time).split(' ')[-1]
    return string

def date_plus_time(date, time):
    # 拼接日期和时间，date是datetime格式，time是str
    return date + pd.Timedelta(hours = int(time.split(':')[0]), minutes = int(time.split(':')[1]), seconds = float(time.split(':')[2]))

def simulate_time(count_p, count_sum, p):
    # 生成某一天的事件链起始时间
    # 初始化空列表，存储生成的数据
    start_fake = []
    # 初始化模拟生成开始时间数组start
    w = int(count_sum * p)
    if w < 1:
        w = 1
    while len(start_fake) < w:
        for j in range(len(count_p)):
            ra_num = np.random.rand()
            if ra_num <= count_p[j]:
                if j <= 59:
                    h = int(0)
                    min = int(j)
                    s = int(0)
                    # s = np.random.randint(60,dtype = int)
                else:
                    h = int(j / 60)
                    min = int(j % 60)
                    s = int(0)
                    # s = np.random.randint(60, dtype=int)
                # if '{}:{}:{}'.format(h, min, s) not in start_fake:
                start_fake.append('{}:{}:{}'.format(h, min, s))
                    # if i == 0:
                    #     id_fake.append('基础事件')
                    # else:
                    #     id_fake.append(impotant_id[i-1])
    # 列表id_fake是告警ID,列表start_fake是按概率模拟的事件触发时间，两个列表是一一对应的
    # print('告警ID',id_fake)
    # print('告警ID',start_fake)
    data_time = pd.DataFrame({'事件触发时间': start_fake})

    # 将字符串先转化为time格式，方便排序
    # 排序完再转化回字符串，方便后面拆分操作
    data_time['事件触发时间'] = pd.to_timedelta(data_time['事件触发时间'])
    data_time = data_time.sort_values(by=['事件触发时间'])  # 排序
    data_time = data_time.reset_index(drop=True)  # 重排索引
    data_time['事件触发时间'] = data_time['事件触发时间'].apply(time_to_str)  # 转化回字符串

    return data_time

conf = ConfigParser()  # 需要实例化一个ConfigParser对象
conf.read(r'./config.ini',encoding='utf-8')  # 需要添加上config.ini的路径，不需要open打开，直接给文件路径就读取，也可以指定encoding='utf-8'

# 读取事件产生规律文件
data_law = pd.read_csv(conf.get('Input', 'file'), encoding='utf-8')

#读取并发规律文件
concurrent_law = pd.read_csv(conf.get('Input', 'concurrent_law'), encoding='gbk')

# 读取影响因子文件
# data_example = pd.read_csv(r'./输入/配置参数表.csv', encoding='gbk')


# 读取事件产生时间文件
# data_time = pd.read_csv(r'./BTS3900 LTE事件产生时间.csv', encoding='utf-8')


# 生成事件产生时间
# 直接嵌入平均数（即每个id平均每天的发生次数）
count_sum = data_law['告警平均数量'].tolist()

# 事件链结束概率，事件链的平均长度为1/p
p = float(conf.get('Set', 'p'))

#读取概率
count_p = data_law[[c for c in data_law.columns if '发生的概率' in c]]
#count_p = pd.read_csv('./输入/网元id每分钟产生概率_80.csv',index_col=0, encoding='gbk')
#count_p = np.array(count_p)
#count_mean = pd.read_csv('./输入/告警事件发生平均数_BTS3900.csv',index_col=0)
#count_mean = np.array(count_mean)

#data_IDs = data_law['告警ID'].unique()    # 要生成的告警ID
# examples = data_example['实例标记'].tolist()      # 要生成的实例
# periods = data_example['仿真时间段'].tolist()     # 要仿真的时间段
period = conf.get('Set', 'period')

process_file = conf.get('Output', 'process file')
if process_file == '':
    f = None
    print_switch = False
else:
    f = open(process_file, 'wt')
    print_switch = True

result = pd.DataFrame(columns=['实例标记', '网元类型', '告警ID', '发生时间(NT)'])
# 读取实例名
example = conf.get('Set', 'example')
# 该实例的仿真时间段的始末日期及具体日期时间，都转化为datetime格式
# begin_date = pd.to_datetime(periods[i].split('-')[0].split(' ')[0])
# end_date = pd.to_datetime(periods[i].split('-')[1].split(' ')[0])
# begin_datetime = pd.to_datetime(periods[i].split('-')[0])
# end_datetime = pd.to_datetime(periods[i].split('-')[1])
begin_date = pd.to_datetime(period.split('-')[0].split(' ')[0])
end_date = pd.to_datetime(period.split('-')[1].split(' ')[0])
begin_datetime = pd.to_datetime(period.split('-')[0])
end_datetime = pd.to_datetime(period.split('-')[1])
continue_days = (end_date-begin_date).days+1   #持续天数
print_switch and print('continue_days:', continue_days, file=f)
# 对输入数据按ID做分组处理
for j in range(data_law.index.size):
    # 幂律指数，幂律方程：P(x)=const * x^-b
    # ID需要转化为字符串，因为data_law中的就是字符串，而ID是int型无法进行匹配
    # 需要重排一下索引，否则不知道索引号
    NE = data_law['网元类型'][j]
    ID = data_law['告警ID'][j]
    b = data_law['幂指数'][j]
    min = data_law['最小时间间隔'][j]
    max = data_law['最大时间间隔'][j]
    #取概率表中的第j行
    count__p = np.array(count_p.iloc[j])
    # 仿真时的日期，和事件链开始时间拼接成一个完整的日期+时间
    now_date = begin_date
    # 当前网元ID生成事件链长度
    count = 0
    flag = False
    while now_date <= end_date:
        print_switch and print(NE, ID, now_date, file=f)
        # 生成当天的事件链起始时间
        print_switch and print('重新生成一天的事件链起始时间', file=f)
        start_time = simulate_time(count__p, count_sum[j], p)
        # 遍历该ID一天内的所有事件链开始时间
        flag1 = False
        for k in range(start_time.index.size):
            flag2 = False
            # 如果这个事件链的开始时间在仿真时间段外，直接不考虑
            if date_plus_time(now_date, start_time['事件触发时间'][k]) < begin_datetime or date_plus_time(now_date,start_time['事件触发时间'][k]) > end_datetime:
                continue
            # 当同一ID的还有事件链未结束，则不启动新的事件链，直接跳过（比较该事件链开始时间和目前仿真到的最新时间即可）
            # 如果它是当前ID的第一个在仿真时间段内的事件链，自然是不需要跳过的
            if not flag and result.index.size > 0 and NE == result['网元类型'][result.index.size-1] and ID == result['告警ID'][result.index.size - 1] and date_plus_time(
                    now_date, start_time['事件触发时间'][k]) < result['发生时间(NT)'][result.index.size - 1]:
                print_switch and print(example, NE, ID, date_plus_time(now_date, start_time['事件触发时间'][k]), '跳过', file=f)
                continue
            flag = False
            # 开始生成事件链，先输出事件链开始时间
            result.loc[result.index.size] = {'实例标记': example, '网元类型': NE, '告警ID': ID,
                                             '发生时间(NT)': date_plus_time(now_date, start_time['事件触发时间'][k])}
            print_switch and print(example, NE, ID, date_plus_time(now_date, start_time['事件触发时间'][k]), '开始', file=f)
            while 1:
                # 生成一个0到1的随机数，如果小于等于事件链结束概率，则结束生成事件链
                ran = random.random()
                if ran <= p:
                    print_switch and print(example, NE, ID, result['发生时间(NT)'][result.index.size - 1], '结束', file=f)
                    count+= 1
                    if count > count_sum[j] * continue_days * p:
                        # 生成事件链条数大于要模拟的事件链条数（告警数量除以1/p），结束该网元ID的事件链生成
                        flag2 = True
                    break
                else:
                    time_interval = rndm(min + 1, max + 1, g=-b+1)  # 生成时都加1分钟，因为幂律指数是加1分钟后算出来的
                    last_time = result['发生时间(NT)'][result.index.size - 1]
                    now_time = last_time + pd.Timedelta(minutes=int(time_interval - 1))  # 再减掉1分钟，并取整
                    # 仿真出来的时间在仿真时间段内才写入，否则中止该事件链的生成（其实也就是结束了该ID的事件链生成）
                    if now_time > begin_datetime and now_time < end_datetime:
                        result.loc[result.index.size] = {'实例标记': example, '网元类型': NE, '告警ID': ID, '发生时间(NT)': now_time}
                    else:
                        print_switch and print(example, NE, ID, result['发生时间(NT)'][result.index.size - 1], '结束', file=f)
                        count+= 1
                        if count > count_sum[j] * continue_days * p:
                        # 生成事件链条数大于要模拟的事件链条数（告警数量除以1/p），结束该网元ID的事件链生成
                            flag2 = True
                        break
            if flag2:
                flag1 = True
                break
        if flag1:
            break
        else:
            now_date += pd.Timedelta(days=1)  # 下一天
            if now_date > end_date:
                # 如果模拟完一个月还没有够数量，则再从头生成一遍
                now_date = begin_date
                flag = True

# result['告警产生时间'] = result['告警产生时间'].dt.round('1s')  # 取整到秒
# 结果按发生时间排序
result = result.sort_values(by=['网元类型', '告警ID', '发生时间(NT)'])
result = result.reset_index(drop=True)
print_switch and print(result, file=f)
result.to_csv(conf.get('Output', 'result file'), encoding='gbk', index=False)

if process_file != '':
     f.close()